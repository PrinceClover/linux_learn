#include <stdio.h>

int main()
{
	char *p = NULL;
	*p ='a';
	double a=atof("2");
	printf("%lf\n",a);
	return 0;
}
