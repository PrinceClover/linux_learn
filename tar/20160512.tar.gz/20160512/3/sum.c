int sum(int i,int j)
{
	return i+j;
}
